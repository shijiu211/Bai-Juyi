//获取元素
let button = document.querySelector(".Login_right .userinfo .button")
let userinfo = document.querySelector(".Login_right .userinfo .userinfo")
let password = document.querySelector(".Login_right .userinfo .password")
//创建事件
button.addEventListener('click', function () {
  
})
